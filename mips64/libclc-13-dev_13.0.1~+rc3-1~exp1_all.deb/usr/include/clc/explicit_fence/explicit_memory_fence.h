_CLC_DECL _CLC_OVERLOAD void mem_fence(cl_mem_fence_flags flags);
_CLC_DECL _CLC_OVERLOAD void read_mem_fence(cl_mem_fence_flags flags);
_CLC_DECL _CLC_OVERLOAD void write_mem_fence(cl_mem_fence_flags flags);
