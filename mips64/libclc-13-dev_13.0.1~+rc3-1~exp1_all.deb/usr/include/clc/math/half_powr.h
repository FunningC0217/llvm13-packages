#define __CLC_BODY <clc/math/binary_decl_tt.inc>
#define __CLC_FUNCTION half_powr

#include <clc/math/gentype.inc>

#undef __CLC_BODY
#undef __CLC_FUNCTION
