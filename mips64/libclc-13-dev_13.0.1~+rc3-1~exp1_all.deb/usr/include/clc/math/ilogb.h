#define __CLC_BODY <clc/math/ilogb.inc>

#include <clc/math/gentype.inc>

#undef __CLC_BODY
