#define __CLC_FUNCTION popcount
#define __CLC_BODY <clc/integer/unary.inc>
#include <clc/integer/gentype.inc>
#undef __CLC_FUNCTION
#undef __CLC_BODY
