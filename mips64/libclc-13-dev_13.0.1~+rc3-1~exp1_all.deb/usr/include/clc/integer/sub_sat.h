#define __CLC_BODY <clc/integer/sub_sat.inc>
#include <clc/integer/gentype.inc>
