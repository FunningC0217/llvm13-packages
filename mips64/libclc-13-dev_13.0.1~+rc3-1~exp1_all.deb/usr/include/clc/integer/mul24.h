#define __CLC_BODY <clc/integer/mul24.inc>
#include <clc/integer/integer-gentype.inc>
#undef __CLC_BODY
