#define __CLC_BODY <clc/integer/abs_diff.inc>
#include <clc/integer/gentype.inc>
