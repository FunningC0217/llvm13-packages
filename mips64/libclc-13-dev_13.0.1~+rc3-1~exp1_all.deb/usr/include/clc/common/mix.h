#define __CLC_BODY <clc/common/mix.inc>
#include <clc/math/gentype.inc>
