_CLC_DECL _CLC_OVERLOAD size_t get_num_groups(uint dim);
