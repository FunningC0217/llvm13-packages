_CLC_OVERLOAD _CLC_DECL int atom_inc(volatile local int *p);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_inc(volatile local unsigned int *p);
