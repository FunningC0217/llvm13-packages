#define __CLC_FUNCTION atomic_sub
#include <clc/atomic/atomic_decl.inc>
