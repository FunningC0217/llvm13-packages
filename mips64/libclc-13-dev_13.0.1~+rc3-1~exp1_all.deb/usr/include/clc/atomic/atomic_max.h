#define __CLC_FUNCTION atomic_max
#include <clc/atomic/atomic_decl.inc>
