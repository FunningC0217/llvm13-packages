#ifndef ISL_MAYBE_BASIC_SET_H
#define ISL_MAYBE_BASIC_SET_H

#define ISL_TYPE	isl_basic_set
#include <isl/maybe_templ.h>
#undef ISL_TYPE

#endif
