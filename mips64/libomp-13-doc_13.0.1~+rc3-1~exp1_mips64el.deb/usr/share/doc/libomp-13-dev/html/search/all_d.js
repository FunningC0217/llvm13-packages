var searchData=
[
  ['sched_5ftype',['sched_type',['../group__WORK__SHARING.html#ga56ebd4fa33cbb0497e6157bb3f04d0e2',1,'kmp.h']]],
  ['set',['set',['../classkmp__flag.html#aa9158e2c4191ad98cdf77f95917001cc',1,'kmp_flag']]],
  ['set_5fstderr',['set_stderr',['../classkmp__safe__raii__file__t.html#a12c4b7eef9f50a1be78699786da78f4a',1,'kmp_safe_raii_file_t']]],
  ['set_5fstdout',['set_stdout',['../classkmp__safe__raii__file__t.html#a0329a4f4af75d9bd62fbaf81ce13915f',1,'kmp_safe_raii_file_t']]],
  ['startup_20and_20shutdown',['Startup and Shutdown',['../group__STARTUP__SHUTDOWN.html',1,'']]],
  ['stats_5fflags_5fe',['stats_flags_e',['../group__STATS__GATHERING.html#ga438c2840cc2d516238ea3eb0f4c116b3',1,'kmp_stats.h']]],
  ['statistics_20gathering_20from_20omptb',['Statistics Gathering from OMPTB',['../group__STATS__GATHERING.html',1,'']]],
  ['stats_5fstate_5fe',['stats_state_e',['../group__STATS__GATHERING.html#gaceceb28b590e725a5106b6c90a451243',1,'kmp_stats.h']]],
  ['store',['store',['../classkmp__flag.html#a62d58938451d206a1b76df304ee62134',1,'kmp_flag']]],
  ['synchronization',['Synchronization',['../group__SYNCHRONIZATION.html',1,'']]]
];
