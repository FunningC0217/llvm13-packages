var searchData=
[
  ['logevent',['logEvent',['../group__STATS__GATHERING.html#gga438c2840cc2d516238ea3eb0f4c116b3a53d50e56126850e531164b0bb1848c5e',1,'kmp_stats.h']]]
];
