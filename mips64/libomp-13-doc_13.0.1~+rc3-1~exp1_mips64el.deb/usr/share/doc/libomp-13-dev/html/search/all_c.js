var searchData=
[
  ['reduce_5fcomb',['reduce_comb',['../structkmp__task__red__input.html#aa1e0da6e42dc289b6ce9f9c3753736c0',1,'kmp_task_red_input::reduce_comb()'],['../structkmp__taskred__data.html#a15cf20df32252d9c86da076e46eb27ea',1,'kmp_taskred_data::reduce_comb()'],['../structkmp__taskred__input.html#a78538323ace6851cc112fccabf287a56',1,'kmp_taskred_input::reduce_comb()']]],
  ['reduce_5ffini',['reduce_fini',['../structkmp__task__red__input.html#a1802287ccff20b66eca618c1be5ea156',1,'kmp_task_red_input::reduce_fini()'],['../structkmp__taskred__data.html#a6a2ef27acb2390bcf816c247c7b25803',1,'kmp_taskred_data::reduce_fini()'],['../structkmp__taskred__input.html#a1b325df9c4d359af83998e6c19112105',1,'kmp_taskred_input::reduce_fini()']]],
  ['reduce_5finit',['reduce_init',['../structkmp__task__red__input.html#a377b818af52ae2ed46fb94faae95a097',1,'kmp_task_red_input::reduce_init()'],['../structkmp__taskred__data.html#a001e268612ff2bad567e52105c4480f6',1,'kmp_taskred_data::reduce_init()'],['../structkmp__taskred__input.html#a665e3853fe30289602f489f7fdc01c0e',1,'kmp_taskred_input::reduce_init()']]],
  ['reduce_5forig',['reduce_orig',['../structkmp__taskred__data.html#aaccb9c4b6c0f9e59199df5e9236b67b1',1,'kmp_taskred_data::reduce_orig()'],['../structkmp__taskred__input.html#ab775012d8a2b017f9b6bf599b69f4fad',1,'kmp_taskred_input::reduce_orig()']]],
  ['reduce_5fpend',['reduce_pend',['../structkmp__taskred__data.html#a136953f33cf079cd654a5203e3bd14e2',1,'kmp_taskred_data']]],
  ['reduce_5fpriv',['reduce_priv',['../structkmp__taskred__data.html#a069390fbad8cc73e2b3744fb43718be1',1,'kmp_taskred_data']]],
  ['reduce_5fshar',['reduce_shar',['../structkmp__task__red__input.html#a0f51a34562856643bbed11e689421cf4',1,'kmp_task_red_input::reduce_shar()'],['../structkmp__taskred__data.html#a8660db1b101cd3c518c4e49a6eff037b',1,'kmp_taskred_data::reduce_shar()'],['../structkmp__taskred__input.html#a116e18ac5612355b45510d89c1b9ff80',1,'kmp_taskred_input::reduce_shar()']]],
  ['reduce_5fsize',['reduce_size',['../structkmp__task__red__input.html#a2ac2d7bd15ac511709cff8ef9b74f7a6',1,'kmp_task_red_input::reduce_size()'],['../structkmp__taskred__data.html#a6f0c2deb9fe24d272d2b26500668431a',1,'kmp_taskred_data::reduce_size()'],['../structkmp__taskred__input.html#ab2525ccfd30c23ec079ab6041b7a8551',1,'kmp_taskred_input::reduce_size()']]],
  ['reserved_5f1',['reserved_1',['../structident.html#a8a098c07080704af1d89e401a1b4d10f',1,'ident']]],
  ['reserved_5f2',['reserved_2',['../structident.html#a91db2d18476e0a527ba20e04ca2c3e74',1,'ident']]],
  ['reserved_5f3',['reserved_3',['../structident.html#ae29e80f6fc150f73c1790c8796bcfd9f',1,'ident']]]
];
