var searchData=
[
  ['parallel_20_28fork_2fjoin_29',['Parallel (fork/join)',['../group__PARALLEL.html',1,'']]]
];
